$(document).ready(function () {
    $("input[name='nome_cidade']").blur(function () {
        var $cod_posto = $("input[name='cod_posto']");
		   
		   
		   
        var nome_cidade = $(this).val();
        
        $.getJSON('proc_pesq_user2.php', {nome_cidade},
            function(retorno){
                $cod_posto.val(retorno.cod_posto);
                
            }
        );        
    });
});