<?php
$servidor="identidadedoc.online";
$usuario="u390726969_sande3";
$senha="perito25";
$dbname= "u390726969_conveniados";

$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>